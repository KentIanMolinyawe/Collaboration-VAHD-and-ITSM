<?php
include "db_conn.php";

if(isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);

    $sql = "SELECT * FROM `support` WHERE id = $id";

    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $ticket = mysqli_fetch_assoc($result); // Display ticket details here
        ?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>View Ticket</title>
        </head>
        
        <body>
            <div class="container-wrapper">
                <div class="container">
                    <h1>Ticket Details</h1>
                    <p><strong>Ticket Number:</strong> <?php echo $ticket["id"]; ?></p>
                    <p><strong>Full Name:</strong> <?php echo $ticket["s_name"]; ?></p>
                    <p><strong>Student Number:</strong> <?php echo $ticket["s_number"]; ?></p>
                    <p><strong>Email:</strong> <?php echo $ticket["s_email"]; ?></p>
                    <p><strong>Issue Description:</strong> <?php echo $ticket["s_discription"]; ?></p>
                    <p><strong>Ticket Age:</strong> <?php echo calculateTimeElapsed($ticket["d_created"]); ?></p>
                    <p><strong>Type of Request:</strong> <?php echo $ticket["t_request"]; ?></p>
                    <p><strong>Ticket Status:</strong>
                        <select name="t_status" id="t_status">
                            <option value="Pending">Pending</option>
                            <option value="Assigned">Assigned</option>
                            <option value="Escalated">Escalated</option>
                            <option value="Resolved">Resolved</option>
                            <option value="Closed">Closed</option>
                        </select>
                    </p>

                    <br />
                    <!-- Add Send and Delete buttons -->
                    <!-- <button onclick="sendEmail('<?php echo $ticket["s_email"]; ?>')">Send</button>  -->
                    <a href="ticket_action.php?id=<?php echo $ticket["id"]; ?>" class="delete-button">Delete</a>
                    <a href="itsupport.php" class="btn" id="save-button">Save</a>

                </div>
                <div class="container">
                    <!-- Content of the duplicate container goes here -->
                </div>
            </div>
        </body>

        </html>
        <?php
    } else {
        // If ticket does not exist, display an error message
        echo "Ticket not found.";
    }
} else {
    // If ticket id is not provided, display an error message
    echo "No ticket id provided.";
}
?>

<!-- CSS styles -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #ebd28f;
    }

    .container-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .container {
        width: 900px; /* Fixed width */
        max-width: 900px; /* Adjust as needed */
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
        background: linear-gradient(to bottom, #ddd, #999); /* Gradient background */
        margin: 20px auto; /* Center the container horizontally */
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        border-radius: 5px;
        background-color: #343a40; /* Dark background color */
        color: #fff; /* White text color */
        text-decoration: none; /* No underlining */
        transition: background-color 0.3s; /* Smooth transition for hover effect */
    }

    .btn:hover {
        background-color: #555; /* Darker background color on hover */
        cursor: pointer; /* Change cursor to pointer on hover */
    }
    .delete-button {
        display: inline-block;
        padding: 10px 20px;
        background-color: #dc3545; /* Bootstrap danger color */
        color: #fff;
        border: none;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .delete-button:hover {
        background-color: #c82333; /* Darker red on hover */
        cursor: pointer;
    }

    h1 {
        color: #333;
    }

    p {
        margin-bottom: 10px;
    }
</style>
