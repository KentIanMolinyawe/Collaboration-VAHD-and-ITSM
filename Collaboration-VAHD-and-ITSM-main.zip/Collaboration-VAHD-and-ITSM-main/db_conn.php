<?php

$sname = "localhost";
$unmae = "root";
$password = "";
$db_name = "test_db";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
    // echo "Connection failed!";
    die("Connection Failed " . mysqli_connect_error());
}
// echo "Connected Succesfully";

if (isset($_POST['submit'])) {
    $s_name = $_POST['s_name'];
    $s_number = $_POST['s_number'];
    $s_email = $_POST['s_email'];
    // $s_subject = $_POST['s_subject'];
    $s_discription = $_POST['s_discription'];
    $t_request = $_POST['t_request'];
    $t_status = $_POST['t_status'];

    $sql = "INSERT INTO `support`(`id`, `s_name`, `s_number`,`s_email`, `s_discription`, `t_request`, `t_status`) 
            VALUES (NULL,'$s_name','$s_number','$s_email','$s_discription','$t_request','$t_status')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location:main.php? msg=New Ticket Created Succesfully!");
    } else {
        echo "Failed: " . mysqli_error($conn);
    }
}


date_default_timezone_set('Asia/Singapore');

// Function to calculate time elapsed
function calculateTimeElapsed($timestamp) {
    $now = time();
    $createdTime = strtotime($timestamp);
    
    $elapsed = $now - $createdTime;
    // Check if elapsed time is less than 1 day
    if ($elapsed < 86400) {
        $hours = floor($elapsed / 3600);
        $minutes = floor(($elapsed % 3600) / 60);
        $seconds = $elapsed % 60;
        return sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds); // Format as hours:minutes:seconds
    } else {
        $days = floor($elapsed / 86400);
        return $days . " day" . ($days != 1 ? "s" : ""); // Format as number of days
    }
}